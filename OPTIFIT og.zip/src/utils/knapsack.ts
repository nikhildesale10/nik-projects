import { Exercise, WorkoutPlanItem } from '../types';

/**
 * Fractional Knapsack Algorithm
 * Optimizes the workout plan based on duration and benefit score.
 * @param exercises List of available exercises
 * @param maxDuration Maximum total duration in minutes
 * @returns Optimized list of exercises
 */
export function fractionalKnapsack(exercises: Exercise[], maxDuration: number): WorkoutPlanItem[] {
  // Shuffle exercises first to provide variety when ratios are similar
  const shuffled = [...exercises].sort(() => Math.random() - 0.5);

  // Calculate benefit per minute
  const sortedExercises = shuffled.sort((a, b) => {
    const ratioA = a.benefitScore / a.duration;
    const ratioB = b.benefitScore / b.duration;
    return ratioB - ratioA;
  });

  let currentDuration = 0;
  const plan: WorkoutPlanItem[] = [];

  for (const exercise of sortedExercises) {
    if (currentDuration + exercise.duration <= maxDuration) {
      plan.push({ ...exercise, fraction: 1 });
      currentDuration += exercise.duration;
    } else {
      const remainingTime = maxDuration - currentDuration;
      if (remainingTime > 0) {
        plan.push({ ...exercise, fraction: remainingTime / exercise.duration });
        currentDuration += remainingTime;
      }
      break;
    }
  }

  return plan;
}
