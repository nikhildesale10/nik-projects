import React from 'react';
import { motion } from 'motion/react';
import { Sword, Shield, Zap } from 'lucide-react';

interface DemonGameProps {
  hp: number;
}

const DemonGame: React.FC<DemonGameProps> = ({ hp }) => {
  const isDefeated = hp <= 0;

  return (
    <div className="bg-[#141414] p-6 rounded-2xl text-white shadow-xl overflow-hidden relative">
      <div className="relative z-10">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-serif italic flex items-center gap-2">
            <Sword size={20} className="text-red-500" /> Demon Boss
          </h3>
          <span className={`text-xs font-mono ${isDefeated ? 'text-green-400' : 'text-red-400'}`}>
            {isDefeated ? 'DEFEATED' : `HP: ${Math.round(hp)}/100`}
          </span>
        </div>

        <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden mb-6">
          <motion.div
            initial={{ width: '100%' }}
            animate={{ width: `${hp}%` }}
            className={`h-full ${hp > 50 ? 'bg-red-500' : hp > 20 ? 'bg-orange-500' : 'bg-red-700'}`}
          />
        </div>

        <div className="flex justify-center py-4">
          <motion.div
            animate={isDefeated ? { rotate: 90, opacity: 0.3, scale: 0.8 } : { y: [0, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="relative"
          >
            <div className={`w-24 h-24 rounded-full flex items-center justify-center border-4 ${isDefeated ? 'border-gray-600' : 'border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.5)]'}`}>
              <Zap size={48} className={isDefeated ? 'text-gray-600' : 'text-red-500'} />
            </div>
            {!isDefeated && (
              <motion.div
                animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
              >
                <Shield size={16} />
              </motion.div>
            )}
          </motion.div>
        </div>

        <p className="text-[10px] text-center uppercase tracking-widest opacity-50 mt-4">
          {isDefeated ? 'The demon has been vanquished!' : 'Complete exercises to damage the demon.'}
        </p>
      </div>

      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 blur-3xl rounded-full -mr-16 -mt-16" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/10 blur-3xl rounded-full -ml-16 -mb-16" />
    </div>
  );
};

export default DemonGame;
