import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { Exercise, WorkoutPlanItem } from '../types';
import { fractionalKnapsack } from '../utils/knapsack';
import ExerciseCard from './ExerciseCard';
import DemonGame from './DemonGame';
import { Timer, Play, RefreshCw, LogOut } from 'lucide-react';

import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

interface WorkoutPlannerProps {
  user: { username: string };
  onLogout: () => void;
}

const WorkoutPlanner: React.FC<WorkoutPlannerProps> = ({ user, onLogout }) => {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [duration, setDuration] = useState<number>(10);
  const [plan, setPlan] = useState<WorkoutPlanItem[]>([]);
  const [completedExercises, setCompletedExercises] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchExercises = async () => {
      try {
        let querySnapshot;
        try {
          querySnapshot = await getDocs(collection(db, 'exercises'));
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, 'exercises');
        }
        
        const list: Exercise[] = [];
        const seenNames = new Set<string>();
        querySnapshot?.forEach((doc) => {
          const data = doc.data() as Exercise;
          if (!seenNames.has(data.name)) {
            list.push({ id: doc.id, ...data });
            seenNames.add(data.name);
          }
        });
        setExercises(list);
      } catch (error) {
        console.error('Error fetching exercises:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchExercises();
  }, []);

  const generatePlan = () => {
    const optimizedPlan = fractionalKnapsack(exercises, duration);
    setPlan(optimizedPlan);
    setCompletedExercises(new Set());
  };

  const toggleComplete = (id: string) => {
    const newSet = new Set(completedExercises);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setCompletedExercises(newSet);
  };

  const totalExercises = plan.length;
  const completedCount = completedExercises.size;
  const demonHP = Math.max(0, 100 - (totalExercises > 0 ? (completedCount / totalExercises) * 100 : 0));

  return (
    <div className="min-h-screen bg-[#E4E3E0] p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-4">
          <div>
            <h1 className="text-4xl font-serif italic text-[#141414]">Hello, {user.username}</h1>
            <p className="text-sm uppercase tracking-widest opacity-50">Your Adaptive Fitness Journey</p>
            {exercises.length > 0 && (
              <p className="text-[10px] uppercase tracking-widest font-bold mt-1 text-green-600">
                {exercises.length} Exercises Loaded
              </p>
            )}
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-[#141414]/10 rounded-lg hover:bg-[#141414] hover:text-white transition-all shadow-sm"
          >
            <LogOut size={18} />
            <span className="text-xs uppercase tracking-widest font-bold">Logout</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm">
              <h2 className="text-xl font-serif italic mb-4 flex items-center gap-2">
                <Timer size={20} /> Set Duration
              </h2>
              <div className="space-y-4">
                <input
                  type="range"
                  min="5"
                  max="60"
                  step="5"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="w-full h-2 bg-[#E4E3E0] rounded-lg appearance-none cursor-pointer accent-[#141414]"
                />
                <div className="flex justify-between text-xs uppercase tracking-widest font-bold opacity-50">
                  <span>5m</span>
                  <span className="text-[#141414] opacity-100 text-lg">{duration} Minutes</span>
                  <span>60m</span>
                </div>
                <button
                  onClick={generatePlan}
                  disabled={loading || exercises.length === 0}
                  className="w-full py-3 bg-[#141414] text-white rounded-lg hover:bg-[#141414]/90 transition-colors flex items-center justify-center gap-2 uppercase tracking-widest text-xs font-bold"
                >
                  {plan.length > 0 ? <RefreshCw size={16} /> : <Play size={16} />}
                  {plan.length > 0 ? 'Regenerate Plan' : 'Generate Plan'}
                </button>
              </div>
            </div>

            <DemonGame hp={demonHP} />
          </div>

          <div className="lg:col-span-2 space-y-4">
            {plan.length > 0 ? (
              <>
                <h2 className="text-xl font-serif italic mb-4">Optimized Workout Plan</h2>
                {plan.map((item) => (
                  <ExerciseCard
                    key={item.id}
                    exercise={item}
                    isCompleted={completedExercises.has(item.id)}
                    onToggleComplete={() => toggleComplete(item.id)}
                  />
                ))}
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-12 bg-white/50 rounded-2xl border border-dashed border-[#141414]/20">
                {exercises.length === 0 && !loading ? (
                  <div className="text-center space-y-4">
                    <p className="text-red-500 font-bold uppercase tracking-widest text-xs">System Not Initialized</p>
                    <p className="opacity-50 italic text-sm">
                      No exercises found in the database. <br />
                      Please log in as an admin (nikhildesale340@gmail.com) to seed the initial data.
                    </p>
                  </div>
                ) : (
                  <p className="text-center opacity-50 italic">
                    {loading ? 'Fetching exercises...' : 'Enter your available time and generate a plan to start your workout.'}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkoutPlanner;
