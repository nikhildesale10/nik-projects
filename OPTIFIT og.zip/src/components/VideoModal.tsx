import React, { useState } from 'react';
import { Exercise } from '../types';
import { X, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VideoModalProps {
  exercise: Exercise;
  onClose: () => void;
}

const VideoModal: React.FC<VideoModalProps> = ({ exercise, onClose }) => {
  const [videoError, setVideoError] = useState(false);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#141414]/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl"
        >
          <div className="flex justify-between items-center p-6 border-b border-[#141414]/10">
            <div>
              <h3 className="text-2xl font-serif italic text-[#141414]">{exercise.name}</h3>
              <p className="text-xs uppercase tracking-widest opacity-50">Exercise Demonstration</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#E4E3E0] rounded-full transition-colors"
            >
              <X size={24} />
            </button>
          </div>
          
            <div className="p-6">
              <div className="aspect-video bg-[#141414] rounded-2xl overflow-hidden mb-6 relative group">
                {exercise.videoURL.includes('youtube.com') || exercise.videoURL.includes('youtu.be') ? (
                  <iframe
                    src={exercise.videoURL}
                    title={exercise.name}
                    className="w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : !videoError ? (
                  <video
                    key={exercise.videoURL}
                    src={exercise.videoURL}
                    autoPlay
                    loop
                    muted
                    playsInline
                    controls
                    crossOrigin="anonymous"
                    onError={() => setVideoError(true)}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-8 text-center bg-[#141414]">
                    {exercise.imageURL && (
                      <img 
                        src={exercise.imageURL} 
                        alt={exercise.name}
                        referrerPolicy="no-referrer"
                        className="absolute inset-0 w-full h-full object-cover opacity-30"
                      />
                    )}
                    <div className="relative z-10">
                      <p className="mb-4 opacity-70 text-sm">Video could not be loaded directly.</p>
                      <a 
                        href={exercise.videoURL} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-white text-black rounded-full text-xs uppercase tracking-widest font-bold hover:bg-opacity-90 transition-all flex items-center gap-2"
                      >
                        Open Video in New Tab
                      </a>
                    </div>
                  </div>
                )}
                <div className="absolute top-4 left-4 bg-[#141414]/50 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] uppercase tracking-widest font-bold pointer-events-none">
                  {exercise.videoURL.includes('youtube.com') ? 'YouTube Demo' : 'Demo Video'}
                </div>
              </div>

              {videoError && exercise.imageURL && (
                <div className="mb-6">
                  <h4 className="text-[10px] uppercase tracking-widest font-bold opacity-40 mb-2">Exercise Preview</h4>
                  <img 
                    src={exercise.imageURL} 
                    alt={exercise.name}
                    referrerPolicy="no-referrer"
                    className="w-full rounded-2xl border border-[#141414]/10"
                  />
                </div>
              )}

            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-[#E4E3E0]/30 rounded-2xl">
                <div className="p-2 bg-[#141414] text-white rounded-lg">
                  <Info size={18} />
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-widest mb-1">Instructions</h4>
                  <p className="text-sm text-[#141414]/80 leading-relaxed">
                    {exercise.instructions}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-6 bg-[#E4E3E0]/20 flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-[#141414] text-white rounded-lg text-xs uppercase tracking-widest font-bold hover:bg-[#141414]/90 transition-colors"
            >
              Got it
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default VideoModal;
