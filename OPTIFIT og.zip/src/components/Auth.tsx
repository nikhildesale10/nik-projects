import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { UserProfile } from '../types';

import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

interface AuthProps {
  onAuthSuccess: (user: UserProfile) => void;
}

const Auth: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const userDocRef = doc(db, 'users', userCredential.user.uid);
        let userDoc;
        try {
          userDoc = await getDoc(userDocRef);
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, 'users');
        }
        
        if (userDoc?.exists()) {
          const data = userDoc.data();
          onAuthSuccess({ 
            uid: userCredential.user.uid, 
            ...data,
            createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt 
          } as UserProfile);
        } else {
          // Profile missing, create it automatically
          const role = email === 'nikhildesale340@gmail.com' ? 'admin' : 'user';
          const defaultUsername = email.split('@')[0];
          const newUser: UserProfile = {
            uid: userCredential.user.uid,
            username: defaultUsername,
            email,
            createdAt: new Date().toISOString(),
            role,
          };
          try {
            await setDoc(userDocRef, {
              username: defaultUsername,
              email,
              createdAt: serverTimestamp(),
              role,
            });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, 'users');
          }
          onAuthSuccess(newUser);
        }
      } else {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const role = email === 'nikhildesale340@gmail.com' ? 'admin' : 'user';
        const newUser: UserProfile = {
          uid: userCredential.user.uid,
          username,
          email,
          createdAt: new Date().toISOString(),
          role,
        };
        await setDoc(doc(db, 'users', userCredential.user.uid), {
          username,
          email,
          createdAt: serverTimestamp(),
          role,
        });
        onAuthSuccess(newUser);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#E4E3E0] p-4">
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-xl border border-[#141414]/10">
        <h2 className="text-3xl font-serif italic mb-6 text-[#141414]">
          {isLogin ? 'Welcome Back' : 'Join OPTIFIT'}
        </h2>
        <form onSubmit={handleAuth} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-xs uppercase tracking-widest opacity-50 mb-1">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-3 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg focus:outline-none focus:border-[#141414]"
                required
              />
            </div>
          )}
          <div>
            <label className="block text-xs uppercase tracking-widest opacity-50 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg focus:outline-none focus:border-[#141414]"
              required
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest opacity-50 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg focus:outline-none focus:border-[#141414]"
              required
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#141414] text-white rounded-lg hover:bg-[#141414]/90 transition-colors uppercase tracking-widest text-sm font-bold"
          >
            {loading ? 'Processing...' : isLogin ? 'Login' : 'Register'}
          </button>
        </form>
        <button
          onClick={() => setIsLogin(!isLogin)}
          className="w-full mt-4 text-sm text-[#141414]/60 hover:text-[#141414] transition-colors"
        >
          {isLogin ? "Don't have an account? Register" : 'Already have an account? Login'}
        </button>
      </div>
    </div>
  );
};

export default Auth;
