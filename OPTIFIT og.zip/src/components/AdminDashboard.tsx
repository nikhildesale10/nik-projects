import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, getDocs, query, orderBy, writeBatch, doc, addDoc } from 'firebase/firestore';
import { UserProfile, Exercise } from '../types';
import { LogOut, Users, ShieldCheck, Database, Plus, Trash2 } from 'lucide-react';

import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

interface AdminDashboardProps {
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  
  // New Exercise Form State
  const [newEx, setNewEx] = useState({
    name: '',
    duration: 5,
    benefitScore: 50,
    videoURL: '',
    instructions: ''
  });

  const fetchData = async () => {
    try {
      // Fetch Users
      const userQ = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
      let userSnap;
      try {
        userSnap = await getDocs(userQ);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'users');
      }
      
      const usersList: UserProfile[] = [];
      userSnap?.forEach((doc) => {
        const data = doc.data();
        usersList.push({
          uid: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt,
        } as UserProfile);
      });
      setUsers(usersList);

      // Fetch Exercises
      let exSnap;
      try {
        exSnap = await getDocs(collection(db, 'exercises'));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'exercises');
      }
      
      const exList: Exercise[] = [];
      exSnap?.forEach((doc) => {
        exList.push({ id: doc.id, ...doc.data() } as Exercise);
      });
      setExercises(exList);

    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddExercise = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      try {
        await addDoc(collection(db, 'exercises'), newEx);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'exercises');
      }
      setNewEx({ name: '', duration: 5, benefitScore: 50, videoURL: '', instructions: '' });
      fetchData();
      setFeedback({ message: 'Exercise added!', type: 'success' });
    } catch (error) {
      console.error('Error adding exercise:', error);
      setFeedback({ message: 'Failed to add exercise.', type: 'error' });
    } finally {
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  const handleSeed = async () => {
    setSeeding(true);
    try {
      const batch = writeBatch(db);
      const exercisesData = [
        { 
          name: 'Pushups', 
          duration: 2, 
          benefitScore: 20, 
          videoURL: 'https://www.youtube.com/embed/iodWzQL7Z94',
          instructions: 'Keep your back straight and lower your body until your chest nearly touches the floor. Video: https://youtu.be/iodWzQL7Z94' 
        },
        { 
          name: 'Squats', 
          duration: 2, 
          benefitScore: 18, 
          videoURL: 'https://www.youtube.com/embed/aclHkVaku9U',
          instructions: 'Lower your hips as if sitting in a chair, keeping your chest up and knees behind toes. Video: https://youtu.be/aclHkVaku9U' 
        },
        { 
          name: 'Plank', 
          duration: 1, 
          benefitScore: 15, 
          videoURL: 'https://www.youtube.com/embed/pSHjTRCQxIw',
          instructions: 'Hold a pushup position but on your forearms. Keep your core tight and body in a straight line. Video: https://youtu.be/pSHjTRCQxIw' 
        },
        { 
          name: 'Jumping Jacks', 
          duration: 1, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/iSSAk4XCsRA',
          instructions: 'Jump while spreading your legs and bringing your hands together above your head. Video: https://youtu.be/iSSAk4XCsRA' 
        },
        { 
          name: 'Burpees', 
          duration: 2, 
          benefitScore: 25, 
          videoURL: 'https://www.youtube.com/embed/auBLPXO8Fww',
          instructions: 'A full body exercise combining a squat, pushup, and jump. Video: https://youtu.be/auBLPXO8Fww' 
        },
        { 
          name: 'Lunges', 
          duration: 2, 
          benefitScore: 16, 
          videoURL: 'https://www.youtube.com/embed/QOVaHwm-Q6U',
          instructions: 'Step forward with one leg and lower your hips until both knees are bent at a 90-degree angle. Video: https://youtu.be/QOVaHwm-Q6U' 
        },
        { 
          name: 'Mountain Climbers', 
          duration: 1, 
          benefitScore: 14, 
          videoURL: 'https://www.youtube.com/embed/nmwgirgXLYM',
          instructions: 'In a plank position, alternate bringing your knees toward your chest as fast as possible. Video: https://youtu.be/nmwgirgXLYM' 
        },
        { 
          name: 'Bicycle Crunches', 
          duration: 2, 
          benefitScore: 15, 
          videoURL: 'https://www.youtube.com/embed/9FGilxCbdz8',
          instructions: 'Lie on your back and alternate touching your elbow to the opposite knee. Video: https://youtu.be/9FGilxCbdz8' 
        },
        { 
          name: 'High Knees', 
          duration: 1, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/Zp26q4BY5HE',
          instructions: 'Run in place, bringing your knees as high as possible with each step. Video: https://youtu.be/Zp26q4BY5HE' 
        },
        { 
          name: 'Wall Sit', 
          duration: 2, 
          benefitScore: 10, 
          videoURL: 'https://www.youtube.com/embed/9zS-8L8i1EE',
          instructions: 'Lean against a wall and lower your body until your thighs are parallel to the floor. Hold. Video: https://youtu.be/9zS-8L8i1EE' 
        },
        { 
          name: 'Crunches', 
          duration: 2, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/Xyd_710816M',
          instructions: 'Lie on your back with knees bent and lift your upper body toward your knees. Video: https://youtu.be/Xyd_710816M' 
        },
        { 
          name: 'Tricep Dips', 
          duration: 2, 
          benefitScore: 18, 
          videoURL: 'https://www.youtube.com/embed/6kALZikpaLc',
          instructions: 'Use a chair or bench to lower and raise your body using your arms. Video: https://youtu.be/6kALZikpaLc' 
        },
        { 
          name: 'Step-ups', 
          duration: 2, 
          benefitScore: 15, 
          videoURL: 'https://www.youtube.com/embed/aajhW7n1lS0',
          instructions: 'Step up onto a stable platform and back down, alternating legs. Video: https://youtu.be/aajhW7n1lS0' 
        },
        { 
          name: 'Side Plank', 
          duration: 1, 
          benefitScore: 10, 
          videoURL: 'https://www.youtube.com/embed/N_7u_X_A_yM',
          instructions: 'Hold your body up on your forearm and the side of your foot. Video: https://youtu.be/N_7u_X_A_yM' 
        },
        { 
          name: 'Bird Dog', 
          duration: 2, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/wiFNA3sqjCA',
          instructions: 'On all fours, extend the opposite arm and leg simultaneously. Video: https://youtu.be/wiFNA3sqjCA' 
        },
        { 
          name: 'Superman', 
          duration: 1, 
          benefitScore: 10, 
          videoURL: 'https://www.youtube.com/embed/z6PJMT2y8GQ',
          instructions: 'Lie face down and lift your arms and legs off the floor. Video: https://youtu.be/z6PJMT2y8GQ' 
        },
        { 
          name: 'Glute Bridges', 
          duration: 2, 
          benefitScore: 14, 
          videoURL: 'https://www.youtube.com/embed/wPM8icPu6H8',
          instructions: 'Lie on your back with knees bent and lift your hips toward the ceiling. Video: https://youtu.be/wPM8icPu6H8' 
        },
        { 
          name: 'Russian Twists', 
          duration: 2, 
          benefitScore: 15, 
          videoURL: 'https://www.youtube.com/embed/wkD8rjkodUI',
          instructions: 'Sit with knees bent, lean back slightly, and twist your torso from side to side. Video: https://youtu.be/wkD8rjkodUI' 
        },
        { 
          name: 'Leg Raises', 
          duration: 2, 
          benefitScore: 16, 
          videoURL: 'https://www.youtube.com/embed/l4kQd9eWclE',
          instructions: 'Lie on your back and lift your legs toward the ceiling without bending your knees. Video: https://youtu.be/l4kQd9eWclE' 
        },
        { 
          name: 'Flutter Kicks', 
          duration: 1, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/eGv_S_56I_U',
          instructions: 'Lie on your back and alternate lifting your legs in a small, fast motion. Video: https://youtu.be/eGv_S_56I_U' 
        },
        { 
          name: 'Diamond Pushups', 
          duration: 2, 
          benefitScore: 22, 
          videoURL: 'https://www.youtube.com/embed/J0DnG1_S92I',
          instructions: 'Perform pushups with your hands close together, forming a diamond shape. Video: https://youtu.be/J0DnG1_S92I' 
        },
        { 
          name: 'Wide Pushups', 
          duration: 2, 
          benefitScore: 20, 
          videoURL: 'https://www.youtube.com/embed/rr6eFNNDQdU',
          instructions: 'Perform pushups with your hands wider than shoulder-width apart. Video: https://youtu.be/rr6eFNNDQdU' 
        },
        { 
          name: 'Pike Pushups', 
          duration: 2, 
          benefitScore: 24, 
          videoURL: 'https://www.youtube.com/embed/sposDXWEB0A',
          instructions: 'In a downward dog position, lower your head toward the floor and push back up. Video: https://youtu.be/sposDXWEB0A' 
        },
        { 
          name: 'Box Jumps', 
          duration: 2, 
          benefitScore: 28, 
          videoURL: 'https://www.youtube.com/embed/52r_Ul5k03g',
          instructions: 'Jump onto a stable box or platform and step back down. Video: https://youtu.be/52r_Ul5k03g' 
        },
        { 
          name: 'Calf Raises', 
          duration: 2, 
          benefitScore: 10, 
          videoURL: 'https://www.youtube.com/embed/-M4-G8p8fmc',
          instructions: 'Stand on your toes and lower your heels back to the floor. Video: https://youtu.be/-M4-G8p8fmc' 
        },
        { 
          name: 'Wall Pushups', 
          duration: 2, 
          benefitScore: 12, 
          videoURL: 'https://www.youtube.com/embed/a6YHb9D08lA',
          instructions: 'Perform pushups against a wall for a lower intensity workout. Video: https://youtu.be/a6YHb9D08lA' 
        },
        { 
          name: 'Incline Pushups', 
          duration: 2, 
          benefitScore: 15, 
          videoURL: 'https://www.youtube.com/embed/3WJJvWv_9_o',
          instructions: 'Perform pushups with your hands on an elevated surface. Video: https://youtu.be/3WJJvWv_9_o' 
        }
      ];

      exercisesData.forEach((ex) => {
        const id = ex.name.toLowerCase().replace(/\s+/g, '-');
        const docRef = doc(db, 'exercises', id);
        const imageURL = `https://picsum.photos/seed/${id}/800/450`;
        batch.set(docRef, { ...ex, imageURL });
      });

      try {
        await batch.commit();
        setFeedback({ message: 'Exercises seeded successfully!', type: 'success' });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'exercises');
        setFeedback({ message: 'Failed to seed exercises.', type: 'error' });
      }
      fetchData();
    } catch (error) {
      console.error('Error seeding:', error);
      setFeedback({ message: 'Error seeding exercises. Check console.', type: 'error' });
    } finally {
      setSeeding(false);
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  const handleClearExercises = async () => {
    setSeeding(true);
    try {
      const snap = await getDocs(collection(db, 'exercises'));
      const batch = writeBatch(db);
      snap.forEach((d) => {
        batch.delete(d.ref);
      });
      await batch.commit();
      fetchData();
      setFeedback({ message: 'All exercises cleared.', type: 'success' });
    } catch (error) {
      console.error('Error clearing exercises:', error);
      setFeedback({ message: 'Failed to clear exercises.', type: 'error' });
    } finally {
      setSeeding(false);
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] p-8">
      <div className="max-w-6xl mx-auto">
        {feedback && (
          <div className={`fixed top-4 right-4 z-50 p-4 rounded-xl shadow-lg border backdrop-blur-md ${
            feedback.type === 'success' ? 'bg-green-500/90 border-green-400 text-white' : 'bg-red-500/90 border-red-400 text-white'
          }`}>
            <p className="text-xs uppercase tracking-widest font-bold">{feedback.message}</p>
          </div>
        )}
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-serif italic text-[#141414]">Admin Control</h1>
            <p className="text-sm uppercase tracking-widest opacity-50">Monitoring OPTIFIT Ecosystem</p>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-[#141414]/10 rounded-lg hover:bg-[#141414] hover:text-white transition-all shadow-sm"
          >
            <LogOut size={18} />
            <span className="text-xs uppercase tracking-widest font-bold">Logout</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-[#141414] text-white rounded-xl">
                <Users size={24} />
              </div>
              <span className="text-xs uppercase tracking-widest opacity-50">Total Users</span>
            </div>
            <p className="text-4xl font-mono font-bold">{users.length}</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-[#141414] text-white rounded-xl">
                <ShieldCheck size={24} />
              </div>
              <span className="text-xs uppercase tracking-widest opacity-50">System Status</span>
            </div>
            <p className="text-4xl font-mono font-bold text-green-600">ACTIVE</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm">
            <div className="flex items-center gap-4 mb-2">
              <div className="p-3 bg-[#141414] text-white rounded-xl">
                <Database size={24} />
              </div>
              <span className="text-xs uppercase tracking-widest opacity-50">Database</span>
            </div>
            <div className="flex flex-col gap-2">
              <button
                onClick={handleSeed}
                disabled={seeding}
                className="w-full mt-2 py-2 bg-[#E4E3E0] text-[#141414] rounded-lg hover:bg-[#141414] hover:text-white transition-all text-[10px] uppercase tracking-widest font-bold disabled:opacity-50"
              >
                {seeding ? 'Seeding...' : 'Seed 50 Exercises'}
              </button>
              <button
                onClick={handleClearExercises}
                disabled={seeding}
                className="w-full py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-600 hover:text-white transition-all text-[10px] uppercase tracking-widest font-bold disabled:opacity-50"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Add Exercise Form */}
          <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm">
            <h2 className="text-xl font-serif italic mb-6 flex items-center gap-2">
              <Plus size={20} /> Add New Exercise
            </h2>
            <form onSubmit={handleAddExercise} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest opacity-50 mb-1">Name</label>
                  <input
                    type="text"
                    value={newEx.name}
                    onChange={(e) => setNewEx({ ...newEx, name: e.target.value })}
                    className="w-full p-2 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest opacity-50 mb-1">Duration (min)</label>
                  <input
                    type="number"
                    value={newEx.duration}
                    onChange={(e) => setNewEx({ ...newEx, duration: parseInt(e.target.value) })}
                    className="w-full p-2 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg text-sm"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest opacity-50 mb-1">Benefit Score</label>
                  <input
                    type="number"
                    value={newEx.benefitScore}
                    onChange={(e) => setNewEx({ ...newEx, benefitScore: parseInt(e.target.value) })}
                    className="w-full p-2 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest opacity-50 mb-1">Video URL</label>
                  <input
                    type="url"
                    value={newEx.videoURL}
                    onChange={(e) => setNewEx({ ...newEx, videoURL: e.target.value })}
                    className="w-full p-2 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg text-sm"
                    placeholder="https://..."
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest opacity-50 mb-1">Instructions</label>
                <textarea
                  value={newEx.instructions}
                  onChange={(e) => setNewEx({ ...newEx, instructions: e.target.value })}
                  className="w-full p-2 bg-[#E4E3E0]/50 border border-[#141414]/10 rounded-lg text-sm h-20"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-[#141414] text-white rounded-lg hover:bg-[#141414]/90 transition-colors uppercase tracking-widest text-[10px] font-bold"
              >
                Save Exercise
              </button>
            </form>
          </div>

          {/* Exercise List */}
          <div className="bg-white p-6 rounded-2xl border border-[#141414]/10 shadow-sm overflow-hidden flex flex-col">
            <h2 className="text-xl font-serif italic mb-6">Current Exercises ({exercises.length})</h2>
            <div className="flex-1 overflow-y-auto max-h-[300px] space-y-2 pr-2">
              {exercises.map((ex) => (
                <div key={ex.id} className="flex justify-between items-center p-3 bg-[#E4E3E0]/30 rounded-lg border border-[#141414]/5">
                  <div>
                    <p className="font-bold text-sm">{ex.name}</p>
                    <p className="text-[10px] opacity-50 uppercase tracking-widest">{ex.duration}m | Score: {ex.benefitScore}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-[#141414]/10 shadow-sm overflow-hidden">
          <div className="p-6 border-bottom border-[#141414]/10">
            <h2 className="text-xl font-serif italic">Registered Users</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#E4E3E0]/30">
                  <th className="p-4 text-xs uppercase tracking-widest opacity-50 font-bold border-b border-[#141414]/10">Username</th>
                  <th className="p-4 text-xs uppercase tracking-widest opacity-50 font-bold border-b border-[#141414]/10">Email</th>
                  <th className="p-4 text-xs uppercase tracking-widest opacity-50 font-bold border-b border-[#141414]/10">Role</th>
                  <th className="p-4 text-xs uppercase tracking-widest opacity-50 font-bold border-b border-[#141414]/10">Joined</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={4} className="p-12 text-center opacity-50 italic">Loading user data...</td>
                  </tr>
                ) : users.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-12 text-center opacity-50 italic">No users registered yet.</td>
                  </tr>
                ) : (
                  users.map((user) => (
                    <tr key={user.uid} className="hover:bg-[#E4E3E0]/20 transition-colors">
                      <td className="p-4 border-b border-[#141414]/10 font-medium">{user.username}</td>
                      <td className="p-4 border-b border-[#141414]/10 font-mono text-sm">{user.email}</td>
                      <td className="p-4 border-b border-[#141414]/10">
                        <span className={`px-2 py-1 rounded text-[10px] uppercase tracking-widest font-bold ${user.role === 'admin' ? 'bg-[#141414] text-white' : 'bg-[#E4E3E0] text-[#141414]'}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="p-4 border-b border-[#141414]/10 text-sm opacity-60">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
