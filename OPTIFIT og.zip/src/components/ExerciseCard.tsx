import React, { useState, useEffect } from 'react';
import { WorkoutPlanItem } from '../types';
import { Play, Pause, RotateCcw, CheckCircle2, Info, Video } from 'lucide-react';
import VideoModal from './VideoModal';

interface ExerciseCardProps {
  exercise: WorkoutPlanItem;
  isCompleted: boolean;
  onToggleComplete: () => void;
}

const ExerciseCard: React.FC<ExerciseCardProps> = ({ exercise, isCompleted, onToggleComplete }) => {
  const [timeLeft, setTimeLeft] = useState(exercise.duration * 60 * exercise.fraction);
  const [isActive, setIsActive] = useState(false);
  const [showVideo, setShowVideo] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.play().catch(e => console.log('Audio play failed', e));
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const resetTimer = () => {
    setTimeLeft(exercise.duration * 60 * exercise.fraction);
    setIsActive(false);
  };

  return (
    <div className={`bg-white p-6 rounded-2xl border transition-all ${isCompleted ? 'border-green-500/50 bg-green-50/30' : 'border-[#141414]/10 shadow-sm'}`}>
      <div className="flex flex-col md:flex-row justify-between gap-6">
        <div className="flex gap-4 flex-1">
          {exercise.imageURL && (
            <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 border border-[#141414]/5">
              <img 
                src={exercise.imageURL} 
                alt={exercise.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-xl font-serif italic">{exercise.name}</h3>
              {exercise.fraction < 1 && (
                <span className="text-[10px] bg-[#141414] text-white px-2 py-0.5 rounded uppercase tracking-widest font-bold">
                  Partial: {Math.round(exercise.fraction * 100)}%
                </span>
              )}
            </div>
            <p className="text-xs uppercase tracking-widest opacity-50 mb-4">
              Duration: {Math.round(exercise.duration * exercise.fraction)}m | Benefit: {Math.round(exercise.benefitScore * exercise.fraction)}
            </p>
            
            <div className="flex gap-2">
              <button
                onClick={() => setShowVideo(true)}
                className="flex items-center gap-2 px-3 py-1.5 bg-[#E4E3E0] rounded-lg hover:bg-[#141414] hover:text-white transition-all text-[10px] uppercase tracking-widest font-bold"
              >
                <Video size={14} /> Demo
              </button>
              <button
                onClick={onToggleComplete}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all text-[10px] uppercase tracking-widest font-bold ${isCompleted ? 'bg-green-500 text-white' : 'bg-[#E4E3E0] hover:bg-green-500 hover:text-white'}`}
              >
                <CheckCircle2 size={14} /> {isCompleted ? 'Completed' : 'Mark Done'}
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center bg-[#E4E3E0]/30 p-4 rounded-xl min-w-[140px]">
          <div className="text-3xl font-mono font-bold mb-3">{formatTime(timeLeft)}</div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsActive(!isActive)}
              className="p-2 bg-[#141414] text-white rounded-full hover:scale-110 transition-transform"
            >
              {isActive ? <Pause size={16} /> : <Play size={16} />}
            </button>
            <button
              onClick={resetTimer}
              className="p-2 bg-white border border-[#141414]/10 rounded-full hover:scale-110 transition-transform"
            >
              <RotateCcw size={16} />
            </button>
          </div>
        </div>
      </div>

      {showVideo && (
        <VideoModal
          exercise={exercise}
          onClose={() => setShowVideo(false)}
        />
      )}
    </div>
  );
};

export default ExerciseCard;
