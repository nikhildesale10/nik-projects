import React, { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, getDocs, writeBatch, serverTimestamp } from 'firebase/firestore';
import { UserProfile } from './types';
import Auth from './components/Auth';
import AdminDashboard from './components/AdminDashboard';
import WorkoutPlanner from './components/WorkoutPlanner';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Safety timeout to prevent infinite loading if Firebase hangs
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 5000);

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      clearTimeout(timeout);
      try {
        if (firebaseUser) {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUser({ 
              uid: firebaseUser.uid, 
              ...data,
              createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt 
            } as UserProfile);
          } else if (firebaseUser.email) {
            // Auto-create profile if authenticated but missing
            const role = firebaseUser.email === 'nikhildesale340@gmail.com' ? 'admin' : 'user';
            const defaultUsername = firebaseUser.email.split('@')[0];
            const userData = {
              username: defaultUsername,
              email: firebaseUser.email,
              createdAt: serverTimestamp(),
              role,
            };
            await setDoc(userDocRef, userData);
            setUser({ uid: firebaseUser.uid, ...userData, createdAt: new Date().toISOString() } as UserProfile);
          }
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Auth state change error:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Removed auto-seeding reload logic to prevent infinite loops
  // Manual seeding is available in AdminDashboard

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#E4E3E0] gap-4">
        <Loader2 className="animate-spin text-[#141414]" size={48} />
        <p className="text-xs uppercase tracking-widest opacity-50">Initializing OPTIFIT...</p>
        <button 
          onClick={() => setLoading(false)}
          className="mt-4 px-4 py-2 bg-white border border-[#141414]/10 rounded-lg text-[10px] uppercase tracking-widest font-bold hover:bg-[#141414] hover:text-white transition-all"
        >
          Skip Loading
        </button>
      </div>
    );
  }

  if (!user) {
    return <Auth onAuthSuccess={setUser} />;
  }

  return (
    <div className="min-h-screen bg-[#E4E3E0]">
      {user.role === 'admin' ? (
        <AdminDashboard onLogout={handleLogout} />
      ) : (
        <WorkoutPlanner user={user} onLogout={handleLogout} />
      )}
    </div>
  );
}
