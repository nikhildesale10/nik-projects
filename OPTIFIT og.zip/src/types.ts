export interface UserProfile {
  uid: string;
  username: string;
  email: string;
  createdAt: string;
  role: 'admin' | 'user';
}

export interface Exercise {
  id: string;
  name: string;
  duration: number; // in minutes
  benefitScore: number;
  videoURL: string;
  imageURL?: string;
  instructions: string;
}

export interface WorkoutPlanItem extends Exercise {
  fraction: number; // For fractional knapsack
}
